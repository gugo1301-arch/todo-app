const list = document.getElementById("list");
const taskInput = document.getElementById("taskInput");

function fetchTodos() {
  fetch("/todos")
    .then(res => res.json())
    .then(data => {
      list.innerHTML = "";
      data.forEach(todo => {
        const li = document.createElement("li");
        li.textContent = todo.task;

        const editBtn = document.createElement("button");
        editBtn.textContent = "Edit";
        editBtn.onclick = () => {
          const newTask = prompt("Edit task:", todo.task);
          if (newTask) {
            fetch("/edit", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ id: todo.id, task: newTask })
            }).then(fetchTodos);
          }
        };

        const delBtn = document.createElement("button");
        delBtn.textContent = "Delete";
        delBtn.onclick = () => {
          fetch("/delete", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ id: todo.id })
          }).then(fetchTodos);
        };

        li.appendChild(editBtn);
        li.appendChild(delBtn);
        list.appendChild(li);
      });
    })
    .catch(err => console.error("Fetch todos error:", err));
}

function addTask() {
  const task = taskInput.value.trim();
  if (!task) return;
  fetch("/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ task })
  })
    .then(() => {
      taskInput.value = "";
      fetchTodos();
    })
    .catch(err => console.error("Add task error:", err));
}

// Load tasks when page opens
fetchTodos();