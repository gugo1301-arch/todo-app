const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const bodyParser = require("body-parser");
const path = require("path");

const app = express();
const db = new sqlite3.Database("database.db");

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

// Create table if not exists
db.run(`
CREATE TABLE IF NOT EXISTS todos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task TEXT,
  completed INTEGER
)
`);

// Get all todos
app.get("/todos", (req, res) => {
  db.all("SELECT * FROM todos", [], (err, rows) => {
    if (err) {
      console.error(err);
      res.sendStatus(500);
    } else {
      res.json(rows);
    }
  });
});

// Add a todo
app.post("/add", (req, res) => {
  db.run("INSERT INTO todos (task, completed) VALUES (?,0)", [req.body.task], function(err){
    if(err){
      console.error(err);
      res.sendStatus(500);
    } else {
      res.sendStatus(200);
    }
  });
});

// Edit a todo
app.post("/edit", (req, res) => {
  db.run("UPDATE todos SET task=? WHERE id=?", [req.body.task, req.body.id], function(err){
    if(err){
      console.error(err);
      res.sendStatus(500);
    } else {
      res.sendStatus(200);
    }
  });
});

// Delete a todo
app.post("/delete", (req, res) => {
  db.run("DELETE FROM todos WHERE id=?", [req.body.id], function(err){
    if(err){
      console.error(err);
      res.sendStatus(500);
    } else {
      res.sendStatus(200);
    }
  });
});

// Serve index.html
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

// Start server
app.listen(3000, () => {
  console.log("Server is running at http://localhost:3000");
});