# Todo App
A simple Todo List web app using Node.js, Express, SQLite, HTML, CSS, JS.
